<!DOCTYPE html>
<html>
<head>
	<title>Employee List</title>
</head>
<body>
	<table border="1">
		<thead>
			<tr>
				<th>ID</th>
				<th>Name</th>
				<th>Email</th>
				<th>Phone</th>
				<th>Salary</th>
				<th>Department</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($employee->id); ?></td>
					<td><?php echo e($employee->name); ?></td>
					<td><?php echo e($employee->email); ?></td>
					<td><?php echo e($employee->phone); ?></td>
					<td><?php echo e($employee->salary); ?></td>
					<td><?php echo e($employee->department); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel8_crud_ajax\resources\views/employee.blade.php ENDPATH**/ ?>