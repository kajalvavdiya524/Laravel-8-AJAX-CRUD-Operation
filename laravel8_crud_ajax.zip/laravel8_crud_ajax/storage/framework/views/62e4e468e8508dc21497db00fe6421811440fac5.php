<!DOCTYPE html>
<html>
	<head>
		<title>Payment Success</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	</head>
	<body>
		<div class="container">
			<div class="text-center">
		      <img src="https://png.pngtree.com/png-vector/20190228/ourmid/pngtree-check-mark-icon-design-template-vector-isolated-png-image_711429.jpg" class="mx-auto d-block" width="20%">
		   </div>
			<div class="text-center">
				<h1>Your Payment has been Succeed</h1>
				<a href="rp" class="btn btn-lg btn-primary mt-3">Back</a>
			</div>
		</div>
	</body>
</html><?php /**PATH C:\xampp\htdocs\laravel8_crud_ajax\resources\views/success.blade.php ENDPATH**/ ?>