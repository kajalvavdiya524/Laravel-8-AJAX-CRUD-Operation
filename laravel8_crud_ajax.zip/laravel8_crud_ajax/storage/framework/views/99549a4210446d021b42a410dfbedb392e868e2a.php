<html>
  <head>
  	<title>Laravel 8 Ajax Image Upload with validation</title>
  	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  	<script src="http://malsup.github.com/jquery.form.js"></script>
  </head>
  <body>

  <div class="container">
    <h1>Laravel 8 Ajax Image Upload with validation</h1>
       <div class="alert" id="message" style="display: none"></div>

    <!-- <form action="<?php echo e(route('employeeImageUpload')); ?>" enctype="multipart/form-data" method="POST"> -->
      <form method="post" id="upload_form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
      	<div class="alert alert-danger print-error-msg" style="display:none">
          <ul></ul>
        </div>
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="form-group">
          <label>Name</label>
          <input type="text" name="name" class="form-control" placeholder="Name">
        </div>
	      <div class="form-group">
          <label>Image</label>
          <input type="file" name="image" class="form-control">
        </div>
        <div class="form-group">
          <button class="btn btn-success upload-image" type="submit">Upload Image</button>
        </div>
      </form>
      <span id="uploaded_image"></span>
    </div>

  <script>
  $(document).ready(function(){

    $('#upload_form').on('submit', function(event){
      event.preventDefault();
      $.ajax({
         url:"<?php echo e(url('employeeImageUpload')); ?>",
         method:"POST",
         data:new FormData(this),
         dataType:'JSON',
         contentType: false,
         cache: false,
         processData: false,
      success:function(data)
      { 
        $('#message').removeClass("alert-danger alert-success");
        $('#message').css('display', 'block');
        $('#message').html(data.success);
        $('#message').addClass(data.class_name);
        $('#uploaded_image').html(data.uploaded_image);
      }
    })
   });
  });
  </script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\laravel8_crud_ajax\resources\views/employeeImageUpload.blade.php ENDPATH**/ ?>