<!DOCTYPE html>
<html>
<head>
	<title>Import</title>
</head>
<body>
	<form method="POST" action="<?php echo e(route('employee.import')); ?>" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<label>Choose CSV : </label>
		<input type="file" name="file">
		<button type="submit">Submit</button>
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel8_crud_ajax\resources\views/import-form.blade.php ENDPATH**/ ?>