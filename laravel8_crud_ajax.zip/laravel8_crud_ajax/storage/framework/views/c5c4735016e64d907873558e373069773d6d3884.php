<!DOCTYPE html>
<html>
    <head>
        <title>Razorpay Payment Intigration</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container mt-3 col-6 mx-auto pt-5">
            <div class="text-center">
                <img src="https://lh3.googleusercontent.com/lAJPinE4zkFc2Im7tQfKYVddiYwj_BiaA2C0ZSu2txv4g5sTl3OMKSTK0snsyQMT_3tPRKxTBVpmxhQMAq6x5TQ-EA=w800" class="img-fluid responsive" width="50%">
            </div>
            <form method="post" action="payment">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name" class="form-label">Enter Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name">
                </div>
                <div class="form-group">
                    <label for="amount" class="form-label">Enter Amount</label>
                    <input type="number" class="form-control" id="amount" name="amount" placeholder="Enter Amount">
                </div>
                <button type="submit" class="btn btn-primary btn-block">Submit</button>
            </form>
        </div>
        <?php if(Session::has('amount')): ?>
            <div class="container text-center">
                <form action="pay" method="POST">
                    <script
                        src="https://checkout.razorpay.com/v1/checkout.js"
                        data-key="rzp_test_BRpjec0iL2Mat3"
                        data-amount="<?php echo e(Session::get('amount')); ?>"
                        data-currency="INR"
                        data-order_id="<?php echo e(Session::get('order_id')); ?>"
                        data-buttontext="Pay with Razorpay"
                        data-name="Coffee"
                        data-description="Test Transaction"
                        data-theme.color="#002a72">
                    </script>
                    <input type="hidden" custom="Hidden Element" name="hidden">
                </form>
            </div>
        <?php endif; ?>
        <script type="text/javascript">
            $(document).ready(function(){
                <?php if(Session::has('amount')): ?>
                    $(".razorpay-payment-button").click().hide();
                <?php endif; ?>
            });
        </script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravel8_crud_ajax\resources\views/index.blade.php ENDPATH**/ ?>